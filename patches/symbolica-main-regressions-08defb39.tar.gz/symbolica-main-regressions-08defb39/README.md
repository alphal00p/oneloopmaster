# Symbolica regression patches

Base: 08defb398420ab07a428876d4fd10eaf6016470f

Seven upstream patch proposals, including regression tests. See
symbolica-main-regressions.md for reproductions, validation and compatibility
notes. SymJIT issues and non-inlined-function performance are excluded.

Verify the extracted files from this directory:

    sha256sum --check SHA256SUMS

From a clean Symbolica checkout at the base above, set BUNDLE to the absolute
path of this extracted directory, then check and apply the patches:

    git apply --check "$BUNDLE"/*.patch
    git apply "$BUNDLE"/*.patch

The series file lists the patches in report order. The build-metadata patch
retains automatic Git version discovery; it does not implement the alternative
of using only Cargo's package version.

The JIT-settings patch changes serialized JIT payloads; existing such payloads
must be regenerated. See the report for test commands and other API notes.
